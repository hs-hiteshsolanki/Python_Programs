from django.apps import AppConfig


class GarageManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'garage_management'
