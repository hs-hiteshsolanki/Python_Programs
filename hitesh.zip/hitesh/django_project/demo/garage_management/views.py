from django.http import HttpResponse
from django.shortcuts import redirect
from django.template import loader

from .models import customer,vehicle,bill


# Create your views here.
def customer_all(request):
    mycontacts = customer.objects.all().values()
    template = loader.get_template('all_customer.html')
    context = {
        'mycontacts' : mycontacts,
    }
    return HttpResponse(template.render(context,request))

def details(request, id):
    mycontact = customer.objects.get(id = id)
    template = loader.get_template('details.html')
    context = {
        'mycontact' : mycontact,
    }
    return HttpResponse(template.render(context,request))

def vehicle_details(request):
    myvehicle = vehicle.objects.all().values()
    template = loader.get_template('all_vehicle.html')
    context = {
        'myvehicle' : myvehicle
    }
    return HttpResponse(template.render(context,request))

def customer_view(request):
    mycontacts = customer.objects.all().values()
    template = loader.get_template('customer.html')
    context = {
        'mycontacts': mycontacts,
    }
    return HttpResponse(template.render(context,request))

def vehicle_view(request):
    myvehicle = vehicle.objects.all().values()
    template = loader.get_template('vehicle.html')
    context = {
        'myvehicle' : myvehicle
    }
    return HttpResponse(template.render(context,request))

def bill_view(request):
    mybill = bill.objects.all().values()
    template = loader.get_template('bill.html')
    context = {
        'mybill' : mybill
    }
    return HttpResponse(template.render(context,request))

def customer_store(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        age = request.POST.get('age')
        dob = request.POST.get('dob')
        number = request.POST.get('number')
        email = request.POST.get('email')

        customers = customer(name= name,age=age,dob=dob,number=number,email=email)
        customers.save()

        return redirect('/customer/')
    else:
        return HttpResponse("Invalid request method.")

def customer_edit(request,id):
    mycontacts = customer.objects.get(id=id)
    template = loader.get_template('customer_update.html')
    context = {
        'mycontacts': mycontacts,
    }
    return HttpResponse(template.render(context, request))

def customer_update(request, id):
    if request.method == 'POST':

        name = request.POST.get('name')
        age = request.POST.get('age')
        dob = request.POST.get('dob')
        number = request.POST.get('number')
        email = request.POST.get('email')

        mycontacts = customer.objects.get(id=id)
        mycontacts.name =name
        mycontacts.age =age
        mycontacts.dob =dob
        mycontacts.number =number
        mycontacts.email =email

        # customers = customer(name= name,age=age,dob=dob,number=number,email=email)
        mycontacts.save()

        return redirect('/customer/')
    else:
        return HttpResponse("Invalid request method.")

def customer_delete(request, id):
    customr =customer.objects.get(id = id )
    customr.delete()
    return redirect('/customer/')

def vehicle_store(request):
    if request.method == 'POST':
        number_plate = request.POST.get('number_plate')
        model = request.POST.get('model')
        owner_id = request.POST.get('owner_id')

        vehicles =vehicle(number_plate= number_plate,model=model,owner_id=owner_id)
        vehicles.save()

        return redirect('/vehicle/')
    else:
        return HttpResponse("Invalid request method.")

def vehicle_edit(request,id):
    myvehicle= vehicle.objects.get(id=id)
    template = loader.get_template('vehicle_update.html')
    context = {
        'myvehicle': myvehicle,
    }
    return HttpResponse(template.render(context, request))

def vehicle_update(request, id):
    if request.method == 'POST':

        number_plate = request.POST.get('number_plate')
        model = request.POST.get('model')
        owner_id = request.POST.get('owner_id')

        myvehicle = vehicle.objects.get(id=id)
        myvehicle.number_plate =number_plate
        myvehicle.model =model
        myvehicle.owner_id =owner_id
        myvehicle.save()

        return redirect('/vehicle/')
    else:
        return HttpResponse("Invalid request method.")

def vehicle_delete(request, id):
    vehicl =vehicle.objects.get(id = id )
    vehicl.delete()
    return redirect('/vehicle/')

def bill_store(request):
    if request.method == 'POST':
        bill_number = request.POST.get('bill_number')
        owner_id = request.POST.get('owner_id')
        price = request.POST.get('price')
        vehicle_id = request.POST.get('vehicle_id')

        bills =bill(bill_number= bill_number,owner_id=owner_id,price=price,vehicle_id=vehicle_id)
        bills.save()

        return redirect('/bill/')
    else:
        return HttpResponse("Invalid request method.")

def bill_delete(request, id):
    bills =bill.objects.get(id = id )
    bills.delete()
    return redirect('/bill/')

def bill_edit(request,id):
    mybill= bill.objects.get(id=id)
    template = loader.get_template('bill_update.html')
    context = {
        'mybill': mybill,
    }
    return HttpResponse(template.render(context, request))

def bill_update(request, id):
    if request.method == 'POST':

        bill_number = request.POST.get('bill_number')
        owner_id = request.POST.get('owner_id')
        price = request.POST.get('price')
        vehicle_id = request.POST.get('vehicle_id')

        mybill = bill.objects.get(id=id)
        mybill.bill_number =bill_number
        mybill.owner_id =owner_id
        mybill.price =price
        mybill.vehicle_id =vehicle_id
        mybill.save()

        return redirect('/vehicle/')
    else:
        return HttpResponse("Invalid request method.")
