from django.contrib import admin

from .models import customer,vehicle,bill

# Register your models here.
admin.site.register(customer)
admin.site.register(vehicle)
admin.site.register(bill)