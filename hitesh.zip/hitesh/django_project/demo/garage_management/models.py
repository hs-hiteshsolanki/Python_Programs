from django.db import models

# Create your models here.

class customer(models.Model):
    name = models.CharField(max_length=100,null=False)
    age = models.IntegerField(null=False)
    dob = models.DateField()
    number = models.IntegerField(null=False)
    email = models.CharField(max_length=200,default='')

    def __str__(self):
        return f"{self.name}"

class vehicle(models.Model):
    number_plate = models.CharField(max_length=10,null=False)
    model = models.CharField(max_length=5,null=False)
    owner_id = models.IntegerField(null=False)
    def __str__(self):
        return f"{self.number_plate}"

class bill(models.Model):
    bill_number = models.CharField(max_length=100,null=False)
    owner_id = models.IntegerField()
    price = models.IntegerField()
    vehicle_id = models.IntegerField()
