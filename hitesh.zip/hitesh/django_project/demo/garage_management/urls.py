from django.urls import path
from . import views

urlpatterns = [
    path('', views.customer_all, name='customer'),
    path('details/<int:id>', views.details, name='details'),
    path('vehicledetails/', views.vehicle_details, name='vehicledetails'),

    path('customer/', views.customer_view, name='customer'),
    path('customer_store/', views.customer_store, name='customer_store'),
    path('customer_delete/<int:id>', views.customer_delete, name='customer_delete'),
    path('customer_edit/<int:id>', views.customer_edit, name='customer_edit'),
    path('customer_update/<int:id>', views.customer_update, name='customer_update'),

    path('vehicle/', views.vehicle_view, name='vehicle'),
    path('vehicle_store/', views.vehicle_store, name='vehicle_store'),
    path('vehicle_edit/<int:id>', views.vehicle_edit, name='vehicle_edit'),
    path('vehicle_update/<int:id>', views.vehicle_update, name='vehicle_update'),
    path('vehicle_delete/<int:id>', views.vehicle_delete, name='vehicle_delete'),

    path('bill/', views.bill_view, name='bill'),
    path('bill_store/', views.bill_store, name='bill_store'),
    path('bill_edit/<int:id>', views.bill_edit, name='bill_edit'),
    path('bill_update/<int:id>', views.bill_update, name='bill_update'),
    path('bill_delete/<int:id>', views.bill_delete, name='bill_delete'),
]