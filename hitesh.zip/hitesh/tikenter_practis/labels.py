import tkinter as tk
import tkinter.ttk as ttk

from pygments.styles.dracula import background

# from tkinter import *
# from tkinter.ttk import *

window = tk.Tk()
# greeting = tk.Label(text="Hello, Tkinter")
# greeting.pack()
#
# greeting = tk.Label(text= "Python rocks!")
# greeting.pack()
# window.update()
# window.mainloop()

l1 = tk.Label(text="tk label",
              fg="white",
              bg = "black",
              width = 50,
              height= 20)
l1.pack()

# TTK Not support fg,bg, height
l2 = ttk.Label(text="ttk label",
               foreground="white",
               background = "blue",
               width=20)
l2.pack()
window.mainloop()