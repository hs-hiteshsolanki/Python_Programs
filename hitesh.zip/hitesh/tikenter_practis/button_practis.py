import tkinter as tk

window = tk.Tk()
button = tk.Button(
    text= "Click me",
    width=25,
    height=25,
    bg="yellow",
    fg="blue"
)
button.pack()
window.mainloop()