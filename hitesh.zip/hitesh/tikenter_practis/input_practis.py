import tkinter as tk

def get_value():
    name_value = name.get()
    print("Entry value : ",name_value)
    name.delete(0,tk.END)
    name.insert(0,"python")
    name.insert(0,"real ")


window = tk.Tk()
l1 = tk.Label(text="Enter a name")
l1.pack()
entry = tk.Entry(fg = "yellow",bg="blue",width=50)
entry.pack()

name_label = tk.Label(text="Enter a name")
name_label.pack()
name = tk.Entry()
name.pack()
button = tk.Button(text= "Get value",command=get_value)
button.pack()

name_data= name.get()

window.mainloop()