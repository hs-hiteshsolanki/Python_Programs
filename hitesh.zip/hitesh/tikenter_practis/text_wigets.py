import tkinter as tk


def get_value():
    value = text_box.get("1.0",tk.END)
    print("entered  value is : ",value)
    text_box.delete("1.4",tk.END)
    text_box.insert("1.0","hello root level")
    text_box.insert("2.0", "\nhello root level")

windows = tk.Tk()
text_box = tk.Text()
text_box.pack()

button = tk.Button(text = "click!",command =get_value)
button.pack()
# window.destroy()
windows.mainloop()
