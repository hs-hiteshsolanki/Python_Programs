# list = ["greeks", "for" ,"greeks",1, 2, 3]
# list1 = [['Geeks', 'For'], ['Geeks']]
import functools
import itertools
import operator
from operator import index

from jinja2.lexer import operator_re

# print(list)
# print(len(list))
# print(list[0])

# print(list1[0][0])
# print(list1[0][-2])

# string = input("Enter elements(Space-separated): ")
# lst=string.split()
# print('The list is:', lst)

# n = int(input("Enter a size of list: "))
# element = list(map(int,input("Enter a element").strip().split()))[:n]
# print(element)

List = []
print("Initial blank List: ")

List.append(1)
List.append(2)
List.append(3)
print(List)

for i in range(4,6):
    List.append(i)

print(List)

List.append((5,6))
print(List)

List2=['for','green']
List.append(List2)
print(List)

List.insert(0,43)
List.insert(12,"hitesh")
print(List)

List.extend([8,"greek","alya"])
print(List)
List.reverse()
print(List)

# List.remove(5)
# List.remove(43)
# print(List)

for i in range(1,5):
    List.remove(i)
print(List)

print(List.pop(5))
print(List)

List3 = ['A', 'B', 'C', 'D', 'E', 'F',
        'G', 'H', 'R', 'j', 'k', 'l', 'm', 'S']

print(List3)
print(List3[3:8])
print(List3[3:])

# Sliced_List = List3[:]
# print(Sliced_List)

print(List3[:-6])
print(List3[-6:-4])
print(List3[::-2])

b = List3.copy()
b.append(6)
print(b)

del List3[2:4]
List3.insert(3,str(4))
print(List3)
List3.sort()
print(List3)

# initializing list 1
lis4 = [2, 1, 3, 5]
# initializing list 1
lis5 = [6, 4, 3, ('Cat', 'Bat'), ('Sat', 'Cat'), ('Cat', 'Bat'),
          ('Cat', 'Bat', 'Sat'), [1, 2], [1, 2, 3], [1, 2]]

lis4.extend(lis5)
print(lis4)

# lis4.clear()
print(lis4.index(5,3))
print(lis4)

# for i in range(len(lis4)):
#     print(lis4[i])
print(lis4.count(3))
print(lis4.count(0))
print(lis4.count([1,2]))

lis4.extend('hitesh')
lis4.append(('a','b'))
print(lis4)
print(lis4.remove([1, 2, 3]))
print(lis4.pop(-2),lis4)

lis = [1, 3, 5, 6, 2]
lis1 = [1, 3, 5, 6, 2,4]
# print(functools.reduce(operator.add,lis))
print(list(itertools.accumulate(lis,lambda x,y:x+y)))
# print(iter)
print(sum(lis))
print(max(lis1))

languages = [" Python ", "C Programming", "JavaScript", "Java", 'PHP','Kotlin']
s1 = "hitesh"
# print(len(languages))
print(min(languages))
print(max(languages))

# num = 10
# num = 10.0
# num = "hitesh"
# num = 7+8j
# print(len(num))
print(list(enumerate(s1)))

print(next(enumerate(languages)))

for count, ele in enumerate(languages,start=1):
    print(len(ele) - count -1,ele)

print(operator.mul(2,3))

# res = map(int,lis)
# def double(val):
#     return val*2
# res = map(double,lis)

# first character get
res = list(map(lambda x:x*2,lis))
print(list(res))

# languages = map(str.upper,languages)
# print(list(languages))

# languages = map(lambda s:s[0],languages)
# print(list(languages))

languages = map(str.strip,languages)
print(list(languages))