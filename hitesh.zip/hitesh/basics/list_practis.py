list1 = [1, 2, 3, 4, 5, 6, [7, 8], [7, 8], 2]
print(list1)
print(list1[6][0])
list1.append(10)
print(list1)
# print(list1.clear())
print(list1)
# clear list [:]
# del list1[:]

# delete list
# del list1
fruits = ["apple", "mango", "banana", "cherry", "apple"]
print(list1.count([7, 8]))
print(fruits.count('banana'))

mix = []
mix.append(fruits)
print(mix)
l = {"python", "flutter"}
mix.append(l)
# difference between extend and append
mix.extend("hitesh")

mix.append("hitesh")

print(type(mix))
print(mix)

print(fruits.index("apple"))
fruits.insert(5, 'grap')
print(fruits.insert(-1, (5, 6)))
print(fruits)
print(fruits.index("grap"))

mix = mix + list1
print(mix)
print(mix.pop())
# pop give index it remove index value
print(mix.pop(0))
print(mix)
mix.append(4)
mix.remove(4)
print(mix)

mix.reverse()
print(mix)