import time

# def sum_list(list1):
#     start = time.time()
#     total = 0
#     for num in list1:
#         total += num
#     end = time.time()
#
#     return total,1000*(end-start)
#
# list1 = [1,2,3,4,5,6,7,8,9]
# print(sum_list(list1))

# n = 3  # Assuming n is the input size
# for i in range(n):
#     start = time.time()
#     for j in range(n):
#         print(i, j)
#     end = time.time()
#     time1 =1000*(end-start)
#     print(time1)
#
# start = time.time()
# find_max = lambda a, b, c: max(a, b, c)
# result = find_max(10, 50, 8)
# end = time.time()
# print(result)
# time1 = 1000 * (end - start)
# print(time1)

# n = 100
# i = 0
# count = 0
# while i < n:
#     count = count+1
#     i = i + 1
# print(count)

# number = int(input ("Enter the number of which the user wants to print the multiplication table: "))
# start = time.time()
# # We are using "for loop" to iterate the multiplication 10 times
# print ("The Multiplication Table of: ", number)
# for count in range(1, 100):
#    print (number, 'x', count, '=', number * count)
# end = time.time()
# time1 = end - start
# convert =time.strftime("%H:%M:%S", time.gmtime(time1))
# print(time1)
# print(convert)
#
# #List Comprehension
# num = int(input("Enter a number: "))
# start = time.time()
# # using list comprehension
# table = [num * i for i in range(1, 10000)]
# end = time.time()
# time1 = end - start
# convert =time.strftime("%H:%M:%S", time.gmtime(time1))
# print(table)
# print(time1)
# print(convert)
#
# # Using map and Lamda function
# num = [int(input("Enter a number: "))]
# start = time.time()
# # let's create our lambda function for the table
# table = list(map(lambda x, y: x * y, list(range(1, 111)), num * 10))
# print(table)
# end = time.time()
# time1 = end - start
# convert =time.strftime("%H:%M:%S", time.gmtime(time1))
# print(convert)

