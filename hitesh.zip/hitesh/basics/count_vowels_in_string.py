
# def vowelsCheck(data,vowels):
#
#     data = data.casefold()
#     count = {}.fromkeys(vowels, 0)
#     for letters in data:
#         if letters in vowels:
#             count[letters] +=1
#         return count

def countvowels(data ,vowels):
    num_vowels=0
    for letters in data:
        if letters in vowels:
           num_vowels = num_vowels+1
    return num_vowels

data = input("enter a string : ")
vowels = "aeiou"
# print (vowelsCheck(data, vowels))
print (countvowels(data, vowels))


def fun(var):
    vowels1 =['a','e','i','o','u']
    if var in vowels1:
        return True
    else:
        return False

sequence = ['g', 'h', 'e', 'j', 'k', 's', 'p', 'r']

filtered = filter(fun,data)
for s in filtered:
    print(s)
