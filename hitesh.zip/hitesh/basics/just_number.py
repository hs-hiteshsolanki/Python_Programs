
def number(data):
    positive = []
    negative = []
    for item in data:
        if type(item) != type(1):
            continue
        if type(item) == type(1) and item > 0:
            positive.append(item)
        elif type(item) == type(1) :
            negative.append(item)

    print("Positive numbers in the list: ", positive)
    print("Negative numbers in the list: ", negative)
# list of numbers
data = [10, -21, 4, -45, 66, -93, 1, 'abc']
number(data)
