x = 5
def change():
    global x
    x = x + 5
    print(f"Value of x inside a function :", x)
change()

print(f"Value of x inside a function :", x)
print(x+10)