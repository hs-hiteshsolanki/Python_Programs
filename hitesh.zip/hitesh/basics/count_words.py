user = "the elephent in the room is the biggest in the room the"
chr_count = 0
word_count = 0
store_word = ['the','is','for']
word_list_count = 0
word_list = {}

for words in store_word:
    word_list[words] = 0

for word in user.split():
    word_count += 1

    if word in store_word:
        #word_list_count += 1
        if word not in word_list:
            word_list[word] = 1
        else:
            word_list[word] += 1



chr_count = len(user)

print(f"word count is : {word_count} ")
print(f"character count is : {chr_count} ")
print(f"store word list count is : {word_list} ")

