import math

from PIL.ImImagePlugin import number


def rediansCalculate(num):

    redianVal= math.degrees(num)
    # redianVal = math.radians(num/math.pi)
    print (redianVal)

num = int(input("enter a number"))
rediansCalculate(num)