from math import factorial
from decimal import Decimal, getcontext
import time

# getcontext().prec=1000
# pi_input = input('How many digits of pi would you like?')
# n = int(pi_input)
#
# def cal(n):
#     start = time.time()
#     t= Decimal(0)
#     pi = Decimal(0)
#     deno= Decimal(0)
#
#     for k in range(n):
#         t = ((-1)**k)*(factorial(6*k))*(13591409+545140134*k)
#         deno = factorial(3*k)*(factorial(k)**3)*(640320**(3*k))
#         pi += Decimal(t)/Decimal(deno)
#     pi = pi * Decimal(12) / Decimal(640320 ** Decimal(1.5))
#     pi = 1/pi
#     end = time.time()
#     time1 = end - start
#     convert = time.strftime("%H:%M:%S", time.gmtime(time1))
#     return round(pi,n),time1,convert
#
# print(cal(n))


def binary_search(lst, x):
    """

    :param lst:
    :param x:
    :return:
    """
    start = time.time()
    low = 0
    high = len(lst) - 1
    mid = 0

    while low <= high:

        mid = (high + low) // 2

        # If x is greater, ignore the left half
        if lst[mid] < x:
            low = mid + 1

        # If x is smaller, ignore the right half
        elif lst[mid] > x:
            high = mid - 1

        # means x is present in mid
        else:
            return mid

        # If we reach here, then the element was not present
        return -1
    end = time.time()
    time1 = end - start
    convert =time.strftime("%H:%M:%S", time.gmtime(time1))



# Test list
lst = [ 2, 3, 4, 10, 40 ]
x = 10

# Function call
result = binary_search(lst, x)

if result != -1:
    print("Element is present at index", str(result))
else:
    print("Element is not present in list")