
def discountCalculate(price,discount):

    discountPrice= (discount/price)*100

    calculateDiscount = price - discountPrice

    return float(calculateDiscount)

price = int(input("Enter a price : "))
discount = int(input("Enter a price : "))
print(discountCalculate(price,discount))