
def hide_number(card_number):
    return card_number[-4:]

card_number = input("enter a Credit Card Number : ")
print(hide_number(card_number))