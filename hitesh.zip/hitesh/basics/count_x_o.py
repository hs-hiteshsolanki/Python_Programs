
def ox(s):
    x_count= []
    o_count= []

    for i in s.split():
        if i.islower() == "x":
            x_count = x_count.append(i)

        elif i.islower() == "o":
            o_count = o_count.append(i)

        if len(x_count) == len(o_count):
            return True
        else:
            return False

print(ox("zzoo"))
