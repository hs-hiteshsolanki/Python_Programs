
def decimal_to_binary(num):
    # if num < 1024:
    return bin(num).replace("0b","")[:10]

print (decimal_to_binary(10001))