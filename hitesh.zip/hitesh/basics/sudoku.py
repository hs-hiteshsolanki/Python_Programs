import os

board = [
    [5, 3, 0, 0, 7, 0, 0, 0, 0],
    [6, 0, 0, 1, 9, 5, 0, 0, 0],
    [0, 0, 9, 8, 7, 0, 6, 0, 0],
    [8, 0, 0, 0, 6, 0, 0, 0, 3],
    [4, 0, 0, 8, 0, 3, 0, 0, 1],
    [7, 0, 0, 0, 2, 0, 0, 0, 6],
    [0, 6, 0, 0, 0, 0, 2, 8, 0],
    [0, 0, 0, 4, 1, 9, 0, 0, 5],
    [0, 0, 0, 0, 8, 0, 0, 7, 9]
]


def print_board(board):
    print(f'     1 2 3 || 4 5 6 || 7 8 9')
    print(f'     v v v || v v v || v v v')

    for r_num, row in enumerate(board):
        print(f'{r_num+1} =>',end=" ")
        for col in range(len(board)):
            if col % 3 == 0 and col != 0:
                print("||", end=" ")
            print(f'{board[r_num][col]}', end=" ")
        if (r_num != 0 and r_num != 8) and (r_num+1) % 3 == 0:
            print("\n    =======================")
        else:
            print("\n    -----------------------")


def is_valid(board, row, col, num):
    # check the row
    if num in board[row]:
        return False

    if num in [board[i][col] for i in range(9)]:
        return False

    box_row = row // 3 * 3
    box_col = col // 3 * 3

    for i in range(box_row, box_row + 3):
        for j in range(box_col, box_col + 3):
            if board[i][j] == num:
                return False
    return True


def find_empty(board):
    for i in range(len(board)):
        for j in range(len(board)):
            if board[i][j] == 0:
                return (i, j)
    return None

while True:
    print_board(board)
    row = int(input("Enter  your move in for Row :                         Exit => 000\n"))
    if row == 000:
        break
    column = int(input("Enter  your move in for column : \n"))
    if column == 000:
        break
    num = int(input("Enter a number :\n"))
    if num == 000:
        break

    if board[row][column] == 0 and is_valid(board,row - 1,column - 1,num):
        board[row][column] = num
    else:
        print("Invalid move. try again.")