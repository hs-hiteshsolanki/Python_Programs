
t1 = (1,)
print(type(t1))

t2 = ("hello" , "word")
print(t2[0])

list = [1,2,3,4,5,6,7,"hello","word"]
print(type(list))

convert_list_tuple = tuple(list)
print(type(convert_list_tuple))
print(convert_list_tuple)

t2 = tuple("hitesh")
print(t2)

t3 = ([1,2,3,4,5,6,7,"hello","word"])
print(t3[1])
print(t3[-1])
print(t3[-8])

set1 =set()
print(set1)

set1 =set("hitesh")
print(set1)

set1 =set(["hitesh","solanki","solanki"])
print(set1)

for item in set1:
    print(item)
print("hitesh" in set1)