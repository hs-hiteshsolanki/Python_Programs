
def calculator(num1,op,num2):
    if op == "+":
        result = num1 + num2
    elif op == "-":
        result = num1 - num2
    elif op == "/":
        result = num1 / num2
    elif op == "*":
        result = num1 * num2
    else:
        raise ValueError("Invalid operator")

    return int(result)


num1 = int(input("Enter a number : "))
op = input("Enter a operator (+,-,*,/): ")
num2 = int(input("Enter a number : "))

result = calculator(num1,op,num2)
print(num1,op,num2 , str("="), result)