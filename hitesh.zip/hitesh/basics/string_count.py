
name = "solanki hitesh"
out_put = {}

for chars in name:
    if chars in out_put.keys():
        out_put[chars] +=1
    else:
        out_put[chars] = 1
print(out_put)