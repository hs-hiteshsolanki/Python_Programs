#count characters
name = input("Enter a name : ")
chr_count = {}

for char in name:
    if char in chr_count:
        chr_count[char] += 1
    else:
        chr_count[char] = 1

for char,count in chr_count.items():
    print(f"{char},{count}")