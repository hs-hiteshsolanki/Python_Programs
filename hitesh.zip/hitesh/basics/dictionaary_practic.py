import copy

Dict = {1:'Geeks',2 :'For',3:'Greek',4:'hitesh','a':'hitesh','A':'hitesh'}
print(Dict)

Dict1 = {'name':'Geeks',2:'hitesh',3:[1,2,3,4]}
print(Dict1)

emptyDict ={}
print(emptyDict)

Dict2 = dict([(1,'Geeks'),("name",'hitesh'),(2,0)])
print(Dict2)

nestedDict = {1: 'Geeks', 2: 'For',3: {'A': 'Welcome', 'B': 'To', 'C': 'Geeks'}}
print(nestedDict)

emptyDict[0] = "hitesh"
emptyDict[1] = "solanki"
emptyDict[2] = 5,12,2001
emptyDict[3] = {"word" :{1:'life',2:{'living':'data'}},"humans":"dinosaurs"}
print(emptyDict)
print(emptyDict[2][0])

del (emptyDict[2])
print(emptyDict[3]["word"])
print(emptyDict.get(3))
print(emptyDict)

#dictionary using dict()
myDict=dict(a=1,b=2,c=3,d=4,e=5)
print(myDict)

lil=[1,2,[3,5],4]
lil1=copy.deepcopy(lil)
for item in range(0,len(lil)):
    print(lil[item],end=" ")

print('\r')
lil1[2][0]= 7
for item in range(0,len(lil1)):
    print(lil1[item],end=" ")

print('\r')
for item in range(0,len(lil)):
    print(lil[item],end=" ")

lil2 = copy.copy(lil1)

print('\r')
lil2[2][0]=9
for item in range(0,len(lil2)):
    print(lil2[item],end=" ")

print('\r')
for item in range(0,len(lil1)):
    print(lil1[item],end=" ")


dict1 = dict({1:'k','l':'k'})
print(dict1)

dict1 = dict({(1,'k'),('l','k')})
print(dict1)
print(dict1[1])
print(dict1.get('1',''))