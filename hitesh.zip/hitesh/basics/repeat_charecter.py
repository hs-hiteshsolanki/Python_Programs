#10. Repeat the characters
def checkCharectors(string):
    doubleString = ""
    for item in string:
        doubleString = doubleString + item * 2
    return doubleString

string = input("enter a string : ")
print(checkCharectors(string))