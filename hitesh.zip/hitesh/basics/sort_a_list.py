
def data(num,order):
    if order == "asc":
        num.sort()
        print(num)
    elif order == "desc":
        num.sort(reverse = True)
        print(num)
    elif order == "none":
        print(num)
    else:
        print("you enter a somthing wrong")

num = [3, 2, 4, 1, 3, 5, 6]
order = input("enter a asc, desc and none ")
data(num,order)