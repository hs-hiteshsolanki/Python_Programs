from flask import *

app = Flask(__name__,template_folder='template')

@app.route('/')
def main():
    return render_template('file_uploads.html')

@app.route('/success',methods = ['POST'])
def success():
    if request.method == 'POST':
        file = request.files['file']
        file.save(file.filename)
        return render_template('acknowledgement.html',name = file.filename)

@app.route('/queryparamiter/')
def queryparamiter():
    language = request.args.get('language')
    return f'<h1> The Language is : {language} </h1>'


