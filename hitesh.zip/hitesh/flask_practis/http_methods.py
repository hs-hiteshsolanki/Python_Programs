from flask import request, Flask

app = Flask(__name__)


def do_the_login():
    pass


def show_the_login_form():
    pass


@app.route('/login',methods = ['GET','POST'])
def login():
    if request.method == 'POST':
        return do_the_login()
    else:
        return show_the_login_form()

@app.get('/login')
def login():
    return show_the_login_form()
@app.get('/login')
def login():
    return do_the_login()

