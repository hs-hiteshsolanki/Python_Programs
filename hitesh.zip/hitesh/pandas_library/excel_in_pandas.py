import pandas as pd

file = 'roll.xlsx'

# df = pd.read_excel('roll.xlsx')
# print(df)

sheet1 = pd.read_excel(file,sheet_name=0,
                       index_col=0)

sheet2 = pd.read_excel(file,sheet_name=0,
                       index_col=0)
newdata = pd.concat([sheet1,sheet2])
print(newdata)

print(newdata.head())
print(newdata.tail())
print(newdata.shape)
sorted_column = newdata.sort_values(["Roll No"],ascending=False)
print(sorted_column)

print(newdata["Math"].head())

print(newdata.describe())
print(newdata["Math"].mean())
newdata['Total Mark'] = newdata["Math"] + newdata["Science"]

newdata.to_excel('Output File.xlsx')