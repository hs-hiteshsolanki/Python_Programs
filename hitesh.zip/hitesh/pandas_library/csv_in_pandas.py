import pandas as pd

df = pd.read_csv('data.csv')
# print(df.to_string())

#only return fist five or last five data
df = pd.read_csv('data.csv')
# print(df)

pd.options.display.max_rows =999
print(pd.options.display.max_rows)
# df = pd.read_excel('FSI-2023')
# print(df)

print(df.head(10))
print(df.tail())
print(df.info())