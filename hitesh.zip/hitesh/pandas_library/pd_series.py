import pandas as pd
from pandas import Series

a = [1,2,3]
myvar = pd.Series(a,index=["x","y",'z'])
print(myvar)
# print(myvar[0])

calories = {"day1" : 420,"day2":380,"day3":390}
cl=pd.Series(calories,index=["day1","day2"])
print(cl)

data = {
    "calories":[420,380,390],
    "duration":[50,40,45]
}
cl1 =pd.DataFrame(data,index=["day1","day2","day3"])
print(cl1)
print(cl1.loc[['day1']])
# print(cl1.loc[[0,1]])