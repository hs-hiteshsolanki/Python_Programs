import pandas as pd
from pandas import json_normalize

# Nested dictionary
data_dict = {
    '101': {'Name': 'Alice', 'Details': {'Role': 'Developer', 'Department': 'Engineering'}},
    '102': {'Name': 'Bob', 'Details': {'Role': 'Manager', 'Department': 'Sales'}},
    '103': {'Name': 'Charlie', 'Details': {'Role': 'Analyst', 'Department': 'Marketing'}}
}

json_normalize(data_dict).T.to_excel('detailed_employees.xlsx')