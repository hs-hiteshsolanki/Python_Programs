from flask import Flask, render_template, request

app = Flask(__name__,template_folder='template')

@app.route('/')
@app.route('/home/')
def home():
    return render_template('home.html')

@app.route('/about/')
def about():
    return render_template('about.html')

@app.route('/resume/')
def resume():
    return render_template('resume.html')

@app.route('/contact/')
def contact():
    return render_template('contact.html')

@app.route('/service/')
def service():
    return render_template('service_details.html')

@app.route('/portfolio/')
def portfolio():
    return render_template('portfolio.html')

@app.route('/portfolio_details/')
def portfolio_details():
    return render_template('portfolio_details.html')